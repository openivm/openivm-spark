package org.openivm.spark.common

import com.fasterxml.jackson.databind.ObjectMapper
import io.delta.tables.DeltaTable
import org.apache.spark.sql.delta.DeltaLog
import org.apache.spark.sql.delta.actions.CommitInfo
import org.apache.spark.sql.functions.{col, lit, map_concat, map => sqlMap}
import org.apache.spark.sql.{Row, SparkSession}
import org.openivm.spark.telemetry.BoundedTelemetryRuntime
import org.scalatest.funspec.AnyFunSpec
import org.scalatest.matchers.should.Matchers

import java.lang.management.ManagementFactory
import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.attribute.PosixFilePermissions
import java.nio.file.{Files, Path, Paths, StandardOpenOption}
import java.util.UUID
import java.util.concurrent.{ConcurrentHashMap, CountDownLatch, ScheduledExecutorService, TimeUnit}
import scala.jdk.CollectionConverters._
import scala.util.Try

/** Out-of-diff probe for lane B3 (never committed). */
private[common] object B3Probe {
  val Src = "default.b3p_src"
  val Views: Seq[(String, String)] = Seq(
    "default.b3p_v1" -> s"SELECT symbol, COUNT(*) AS events, SUM(amount) AS total FROM $Src GROUP BY symbol",
    "default.b3p_v2" ->
      s"SELECT symbol, COUNT(*) AS events, SUM(amount) AS total FROM $Src WHERE amount % 3 = 0 GROUP BY symbol",
    "default.b3p_v3" -> s"SELECT symbol, amount FROM $Src WHERE amount % 2 = 1"
  )

  def short(name: String): String = name.substring(name.lastIndexOf('.') + 1).toLowerCase

  def fmt(m: Map[String, Long]): String = m.toSeq.sorted.map { case (k, v) => s"$k:$v" }.mkString(",")

  def driver(root: Path, app: String): SparkSession =
    SparkSession
      .builder()
      .master("local[1]")
      .appName(app)
      .config("spark.ui.enabled", "false")
      .config("spark.plugins", "org.openivm.spark.plugin.metrics.OpenIvmMetricsPlugin")
      .config("spark.openivm.telemetry.queue.enabled", "true")
      .config("spark.openivm.telemetry.queue.localUri", root.resolve("phase-events").toUri.toString)
      .config("spark.driver.host", "localhost")
      .config("spark.driver.bindAddress", "127.0.0.1")
      .config("spark.sql.shuffle.partitions", "1")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension,org.openivm.spark.OpenIvmSparkExtensions")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.catalogImplementation", "hive")
      .config("spark.hadoop.javax.jdo.option.ConnectionURL", s"jdbc:derby:;databaseName=$root/metastore;create=true")
      .config("spark.sql.warehouse.dir", root.resolve("warehouse").toString)
      .config(FeatureGate.EnabledKey, "true")
      .config(FeatureGate.ChangeFeedModeKey, "cdf")
      .config(FeatureGate.QueryLogEnabledKey, "true")
      .config(FeatureGate.CatalogBackendKey, "delta")
      .config(FeatureGate.StatePathKey, root.resolve("state").toString)
      .config(FeatureGate.StateSyncUriKey, root.resolve("remote").toUri.toString)
      .config(FeatureGate.StateSyncAsyncEnabledKey, "false")
      .config(FeatureGate.GcEnabledKey, "false")
      .getOrCreate()

  def external(root: Path): SparkSession =
    SparkSession
      .builder()
      .master("local[1]")
      .appName("b3-probe-external")
      .config("spark.ui.enabled", "false")
      .config("spark.driver.host", "localhost")
      .config("spark.driver.bindAddress", "127.0.0.1")
      .config("spark.sql.shuffle.partitions", "1")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.warehouse.dir", root.resolve("external-warehouse").toString)
      .config("spark.sql.mapKeyDedupPolicy", "LAST_WIN")
      .getOrCreate()

  def launch(root: Path, main: String, args: Seq[String], log: String, timeoutSec: Long = 900L): Option[Int] = {
    val java = Paths.get(System.getProperty("java.home"), "bin", "java").toString
    val modules = ManagementFactory.getRuntimeMXBean.getInputArguments.asScala.toSeq
      .filter(arg => arg.startsWith("--add-opens=") || arg.startsWith("--add-exports="))
    val command = Seq(java, "-Xmx2g") ++ modules ++ Seq("-cp", System.getProperty("java.class.path"), main) ++ args
    val process = new ProcessBuilder(command: _*)
      .redirectErrorStream(true)
      .redirectOutput(root.resolve(s"$log.log").toFile)
      .start()
    try if (process.waitFor(timeoutSec, TimeUnit.SECONDS)) Some(process.exitValue()) else None
    finally if (process.isAlive) process.destroyForcibly()
  }

  private def recordsModule: Option[(Class[_], AnyRef)] =
    Try {
      val cls = Class.forName("org.openivm.spark.common.MvRefreshRecords$")
      (cls: Class[_], cls.getField("MODULE$").get(null))
    }.toOption

  def hasRecords: Boolean = recordsModule.isDefined

  /** Parks the single catalog-finalizer thread until the returned latch opens; None on baseline. */
  def blockFinalizer(): Option[CountDownLatch] = recordsModule.map { case (cls, module) =>
    val method = cls.getDeclaredMethods
      .find(m => (m.getName == "executor" || m.getName.endsWith("$$executor")) && m.getParameterCount == 0)
      .getOrElse(sys.error("finalizer executor accessor not found"))
    method.setAccessible(true)
    val executor = method.invoke(module).asInstanceOf[ScheduledExecutorService]
    val gate     = new CountDownLatch(1)
    val parked   = new CountDownLatch(1)
    executor.submit(new Runnable {
      override def run(): Unit = { parked.countDown(); gate.await() }
    })
    require(parked.await(60, TimeUnit.SECONDS), "finalizer thread did not park")
    gate
  }

  private def module: (Class[AnyRef], AnyRef) = {
    val m = recordsModule.getOrElse(sys.error("no refresh records"))
    (m._1.asInstanceOf[Class[AnyRef]], m._2)
  }

  def pendingMap: ConcurrentHashMap[AnyRef, AnyRef] = {
    val (cls, instance) = module
    val field = cls.getDeclaredFields
      .find(f => f.getName == "pending" || f.getName.endsWith("$$pending"))
      .getOrElse(sys.error("pending not found"))
    field.setAccessible(true)
    field.get(instance).asInstanceOf[ConcurrentHashMap[AnyRef, AnyRef]]
  }

  /** Milliseconds until this JVM has no queued bookkeeping and the finalizer thread is idle; 0 on baseline. */
  def awaitIdle(timeoutMs: Long = 120000L): Long =
    if (!hasRecords) 0L
    else {
      val start = System.nanoTime()
      def elapsed: Long = (System.nanoTime() - start) / 1000000L
      while (!pendingMap.isEmpty && elapsed < timeoutMs) Thread.sleep(100L)
      blockFinalizer().foreach(_.countDown())
      if (pendingMap.isEmpty) elapsed else -1L
    }

  /** This JVM's queued records as tab-separated hint fields, so another driver process can replay them. */
  def pendingLines(): Seq[String] =
    if (!hasRecords) Seq.empty
    else
      pendingMap
        .values()
        .asScala
        .toSeq
        .map { p =>
          def get(name: String): AnyRef = p.getClass.getMethod(name).invoke(p)
          val consumed = get("consumed").asInstanceOf[scala.collection.Map[String, Any]]
          (Seq("catalogPath", "storedName", "viewName", "location", "tableId", "version").map(n => String.valueOf(get(n))) :+
            consumed.toSeq.map { case (s, v) => s"$s=$v" }.sorted.mkString(",")).mkString("\t")
        }
        .sorted

  /** Queues hints captured from another driver in this JVM and schedules the unchanged deferred flush over them. */
  def replayPending(spark: SparkSession, lines: Seq[String]): Int = {
    val (cls, instance) = module
    val pendingClass    = Class.forName("org.openivm.spark.common.MvRefreshRecords$Pending")
    val ctor            = pendingClass.getConstructors.find(_.getParameterCount == 8).getOrElse(sys.error("Pending ctor"))
    val entries = lines.filter(_.nonEmpty).map { line =>
      val f = line.split("\t", -1)
      val consumed: Map[String, Long] =
        if (f(6).isEmpty) Map.empty
        else f(6).split(",").toSeq.map { kv => val i = kv.lastIndexOf('='); kv.take(i) -> kv.drop(i + 1).toLong }.toMap
      val hint = ctor
        .newInstance(spark, f(0), f(1), f(2), f(3), f(4), java.lang.Long.valueOf(f(5).toLong), consumed)
        .asInstanceOf[AnyRef]
      pendingClass.getMethod("key").invoke(hint) -> hint
    }
    entries.foreach { case (key, hint) => pendingMap.put(key, hint) }
    val method = cls.getDeclaredMethods
      .find(m => (m.getName == "scheduleFlush" || m.getName.endsWith("$$scheduleFlush")) && m.getParameterCount == 0)
      .getOrElse(sys.error("scheduleFlush not found"))
    method.setAccessible(true)
    method.invoke(instance)
    entries.size
  }

  def oneLine(e: Throwable): String =
    Option(e.getMessage).getOrElse(e.getClass.getName).replace('\n', ' ').replace('\t', ' ').take(240)

  def attempt(body: => Unit): String = Try(body).map(_ => "ok").recover { case e => s"error:${oneLine(e)}" }.get

  def pid: Long = ProcessHandle.current().pid()

  def writeKv(root: Path, file: String, kv: Seq[(String, Any)]): Unit =
    Files.write(root.resolve(file), kv.map { case (k, v) => s"$k=$v" }.mkString("\n").getBytes(UTF_8))

  def readLines(root: Path, file: String): Seq[String] =
    if (Files.isRegularFile(root.resolve(file))) Files.readAllLines(root.resolve(file), UTF_8).asScala.toSeq
    else Seq(s"$file=missing")

  val probeTarget: Path = Paths.get("target").toAbsolutePath

  def probeTag: String = s"${org.apache.spark.SPARK_VERSION}-${if (hasRecords) "candidate" else "baseline"}"

  def probeRoot(name: String): Path = {
    val root = probeTarget.resolve(s"b3-probe-$name-${UUID.randomUUID().toString.take(8)}")
    Files.createDirectories(root)
    root
  }

  def appendTo(file: Path, lines: Seq[String]): Unit =
    Files.write(file, (lines.mkString("\n") + "\n").getBytes(UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND)

  def tableId(spark: SparkSession, location: String): String =
    Try(DeltaTableVersion.deltaLogFor(spark, location).update().metadata.id).getOrElse("unreadable")

  /** Action counts of the commits at `version` and `version - 1` in a Delta log, e.g. `commitInfo:1,txn:1`. */
  def commitShape(spark: SparkSession, location: String, version: Long): String = {
    val mapper = new ObjectMapper()
    def actions(v: Long): String =
      if (v < 0) "none"
      else {
        val file = new org.apache.hadoop.fs.Path(new org.apache.hadoop.fs.Path(location, "_delta_log"), f"$v%020d.json")
        val fs   = file.getFileSystem(spark.sessionState.newHadoopConf())
        if (!fs.exists(file)) "absent"
        else {
          val in = fs.open(file)
          val text =
            try scala.io.Source.fromInputStream(in)(scala.io.Codec.UTF8).getLines().toList
            finally in.close()
          text
            .filter(_.trim.nonEmpty)
            .map(line => mapper.readTree(line).fieldNames().next())
            .groupBy(identity)
            .toSeq
            .sortBy(_._1)
            .map { case (k, v) => s"$k:${v.size}" }
            .mkString(",")
        }
      }
    s"v$version[${actions(version)}];v${version - 1}[${actions(version - 1)}]"
  }

  def flushLock(): AnyRef = recordsModule
    .map { case (cls, module) =>
      val field = cls.getDeclaredFields
        .find(f => f.getName == "FlushLock" || f.getName.endsWith("$$FlushLock"))
        .getOrElse(sys.error("FlushLock not found"))
      field.setAccessible(true)
      field.get(module)
    }
    .getOrElse(sys.error("no refresh records"))

  /** A raw `mv_metadata` row. */
  final case class Stored(lastVersion: Long, properties: Map[String, String]) {
    def watermarks: Map[String, Long] = properties.collect {
      case (k, v) if k.startsWith(MvMetadata.WatermarkKeyPrefix) && v.startsWith("v:") && Try(v.drop(2).toLong).isSuccess =>
        short(k.stripPrefix(MvMetadata.WatermarkKeyPrefix)) -> v.drop(2).toLong
    }
    def ext: String = properties.filter(_._1.startsWith("ext_")).toSeq.sorted.map { case (k, v) => s"$k=$v" }.mkString(",")
  }

  final class Driver(val spark: SparkSession, root: Path) {
    private val mapper = new ObjectMapper()

    def sql(text: String): Unit = { spark.sql(text).collect(); () }
    private def ident(name: String) = spark.sessionState.sqlParser.parseTableIdentifier(name)
    def reconciled(name: String): MvMetadata =
      MvCatalog.lookup(spark, ident(name)).getOrElse(sys.error(s"$name missing from the catalog"))
    def latest(name: String): Long = DeltaTableVersion.requireLatest(spark, reconciled(name).location)
    def catalogPath: String        = FeatureGate.catalogPath(spark).stripSuffix("/")

    private def exists(path: String): Boolean = {
      val p = new org.apache.hadoop.fs.Path(path)
      p.getFileSystem(spark.sessionState.newHadoopConf()).exists(new org.apache.hadoop.fs.Path(p, "_delta_log"))
    }

    def storedRows: Map[String, Stored] = {
      val path = s"$catalogPath/mv_metadata"
      if (!exists(path)) Map.empty
      else
        spark.read
          .format("delta")
          .load(path)
          .select("name", "last_version", "properties")
          .collect()
          .toSeq
          .map(r => short(r.getString(0)) -> Stored(r.getLong(1), Option(r.getMap[String, String](2)).map(_.toMap).getOrElse(Map.empty)))
          .toMap
    }

    def stored(name: String): Option[Stored] = storedRows.get(short(name))
    def storedVersion(name: String): Long    = stored(name).map(_.lastVersion).getOrElse(-1L)

    def cdfRows: Seq[(String, String, Long)] = {
      val path = s"$catalogPath/cdf_watermarks"
      if (!exists(path)) Seq.empty
      else
        spark.read
          .format("delta")
          .load(path)
          .collect()
          .toSeq
          .map(r => (r.getAs[String]("view_name"), r.getAs[String]("source"), r.getAs[Long]("version")))
          .sorted
    }

    def cdfFor(name: String): Map[String, Long] =
      cdfRows.filter(r => short(r._1) == short(name)).map(r => short(r._2) -> r._3).toMap

    def catalogTableId(table: String): String = {
      val path = s"$catalogPath/$table"
      if (!exists(path)) "absent" else DeltaTableVersion.deltaLogFor(spark, path).update().metadata.id
    }

    def watermarks(meta: MvMetadata): Map[String, Long] =
      meta.changeWatermarks.collect { case (s, ChangeWatermark.DeltaVersion(v)) => short(s) -> v }

    def parity(name: String, query: String): Boolean = {
      val expected = spark.sql(query)
      val actual   = spark.sql(s"SELECT ${expected.columns.mkString(", ")} FROM $name")
      actual.exceptAll(expected).count() == 0L && expected.exceptAll(actual).count() == 0L
    }

    def delta(source: String, step: Int): Unit = {
      sql(
        s"INSERT INTO $source SELECT concat('sym_', cast(id % 10 as string)), cast(${step * 1000} + id as int) " +
          "FROM range(20)"
      )
      sql(s"DELETE FROM $source WHERE symbol = 'sym_${step % 10}' AND amount % 2 = 0")
    }

    def refresh(name: String, requestId: String): Unit = {
      spark.sparkContext.setLocalProperty("openivm.request_id", requestId)
      try sql(s"REFRESH MATERIALIZED VIEW $name")
      finally spark.sparkContext.setLocalProperty("openivm.request_id", null)
    }

    def outcome(requestId: String): String = {
      BoundedTelemetryRuntime.awaitDrain(10000L)
      val dir = root.resolve("phase-events")
      if (!Files.isDirectory(dir)) "missing"
      else {
        val files = Files.list(dir)
        val nodes =
          try
            files
              .iterator()
              .asScala
              .filter(_.getFileName.toString.endsWith(".jsonl"))
              .flatMap(file => Files.readAllLines(file, UTF_8).asScala.map(line => mapper.readTree(line)))
              .toVector
          finally files.close()
        nodes
          .find(n =>
            n.path("request_id").asText() == requestId && n.path("operation").asText() == "refresh" &&
              n.has("effective_refresh_type")
          )
          .map(n => s"${n.path("outcome").asText()}/${n.path("effective_refresh_type").asText()}".toLowerCase)
          .getOrElse("missing")
      }
    }

    def markerTags(name: String): Map[String, String] = {
      val log     = DeltaTableVersion.deltaLogFor(spark, reconciled(name).location)
      val version = log.update().version
      log
        .getChanges(version, failOnDataLoss = false)
        .take(1)
        .toSeq
        .flatMap(_._2)
        .collectFirst { case info: CommitInfo => info.tags.getOrElse(Map.empty[String, String]) }
        .getOrElse(Map.empty[String, String])
        .filter(_._1.startsWith("openivm.refresh"))
    }

    def markerLine(name: String): String = markerTags(name).toSeq.sorted.map { case (k, v) => s"$k=$v" }.mkString(";")

    def flushed(names: Seq[String]): Boolean = names.forall { n =>
      val r    = reconciled(n)
      val rows = cdfFor(n)
      storedVersion(n) == r.lastVersion && watermarks(r).forall { case (s, v) => rows.get(s).exists(_ >= v) }
    }

    /** Milliseconds until the stored catalog matches the reconciled view, or -1 on timeout. */
    def awaitFlushed(names: Seq[String], timeoutMs: Long = 120000L): Long = {
      val start         = System.nanoTime()
      def elapsed: Long = (System.nanoTime() - start) / 1000000L
      while (!flushed(names) && elapsed < timeoutMs) Thread.sleep(200L)
      if (flushed(names)) elapsed else -1L
    }

    def describe(name: String, query: String): String = {
      val r = reconciled(name)
      val s = stored(name)
      s"mv|${short(name)}|stored=${storedVersion(name)}|reconciled=${r.lastVersion}|latest=${latest(name)}" +
        s"|stored_wm=${s.map(m => fmt(m.watermarks)).getOrElse("")}|reconciled_wm=${fmt(watermarks(r))}" +
        s"|ext=${s.map(_.ext).getOrElse("")}|parity=${parity(name, query)}"
    }

    def dump(label: String): Seq[String] =
      Seq(
        s"[$label]",
        s"catalog|mv_metadata=${catalogTableId("mv_metadata")}|cdf_watermarks=${catalogTableId("cdf_watermarks")}"
      ) ++ Views.map { case (n, q) => describe(n, q) } ++ cdfRows.map { case (v, s, ver) => s"cdf|$v|$s|$ver" }
  }
}

/** Another driver writing the catalog and the MV tables through plain Delta. */
private[common] object B3ProbeExternal {
  private def deltaTables(spark: SparkSession, catalog: String): Seq[String] = {
    val root = new org.apache.hadoop.fs.Path(catalog)
    val fs   = root.getFileSystem(spark.sessionState.newHadoopConf())
    fs.listStatus(root)
      .toSeq
      .filter(s => s.isDirectory && fs.exists(new org.apache.hadoop.fs.Path(s.getPath, "_delta_log")))
      .map(_.getPath.getName)
      .sorted
  }

  private def quote(s: String): String = s.replace("\\", "\\\\").replace("'", "\\'")

  def main(args: Array[String]): Unit = {
    val root    = Paths.get(args(0))
    val catalog = args(1).stripSuffix("/")
    val spark   = B3Probe.external(root)
    try args(2) match {
      case "update" =>
        DeltaTable
          .forPath(spark, s"$catalog/mv_metadata")
          .update(
            col("name").endsWith("b3p_v1"),
            Map("properties" -> map_concat(col("properties"), sqlMap(lit("ext_drv"), lit("e1"))))
          )
        val cdfPath = s"$catalog/cdf_watermarks"
        val schema  = spark.read.format("delta").load(cdfPath).schema
        val values: Map[String, Any] =
          Map("view_name" -> "b3p_foreign", "source" -> "b3p_foreign_src", "version" -> 42L)
        spark
          .createDataFrame(
            java.util.Arrays.asList(Row.fromSeq(schema.fieldNames.toSeq.map(f => values.getOrElse(f, null)))),
            schema
          )
          .write
          .format("delta")
          .mode("append")
          .save(cdfPath)
        DeltaTable.forPath(spark, cdfPath).update(col("view_name").endsWith("b3p_v2"), Map("version" -> col("version")))
        println("external update committed")
      case "recreate" =>
        val tag    = args(3)
        val tables = deltaTables(spark, catalog)
        val saved = tables.map { table =>
          val path     = s"$catalog/$table"
          val snapshot = DeltaLog.forTable(spark, path).update()
          val frame    = spark.read.format("delta").load(path)
          (table, frame.schema, frame.collect().toSeq, snapshot.metadata.partitionColumns, snapshot.metadata.configuration)
        }
        val rootPath = new org.apache.hadoop.fs.Path(catalog)
        rootPath.getFileSystem(spark.sessionState.newHadoopConf()).delete(rootPath, true)
        DeltaLog.clearCache()
        saved.foreach { case (table, schema, rows, partitions, configuration) =>
          val tagged =
            if (table != "mv_metadata") rows
            else {
              val index = schema.fieldIndex("properties")
              rows.map { row =>
                val props = row.getMap[String, String](index).toMap + ("ext_drv" -> tag)
                Row.fromSeq(row.toSeq.updated(index, props))
              }
            }
          val path = s"$catalog/$table"
          spark
            .createDataFrame(java.util.Arrays.asList(tagged: _*), schema)
            .write
            .format("delta")
            .partitionBy(partitions: _*)
            .save(path)
          if (configuration.nonEmpty) {
            val props = configuration.toSeq.sorted.map { case (k, v) => s"'${quote(k)}'='${quote(v)}'" }.mkString(", ")
            spark.sql(s"ALTER TABLE delta.`$path` SET TBLPROPERTIES ($props)")
          }
          println(s"recreated $table rows=${rows.size} partitions=${partitions.mkString(",")} conf=${configuration.size}")
        }
      case "foreign" =>
        spark.sql(s"ALTER TABLE delta.`${args(3)}` SET TBLPROPERTIES ('b3p.foreign'='1')")
        DeltaTable.forPath(spark, args(4)).update(lit(true), Map("symbol" -> col("symbol")))
        println("foreign commits written")
      case other => sys.error(s"unknown command $other")
    } finally spark.stop()
  }
}

/** Kills a driver inside the bookkeeping gap, then recovers in a fresh process. */
private[common] object B3ProbeGap {
  val Src   = "default.b3g_src"
  val Mv    = "default.b3g_mv"
  val Query = s"SELECT symbol, COUNT(*) AS events, SUM(amount) AS total FROM $Src GROUP BY symbol"
  val Exit  = 73

  private def write(root: Path, file: String, kv: Seq[(String, Any)]): Unit =
    Files.write(root.resolve(file), kv.map { case (k, v) => s"$k=$v" }.mkString("\n").getBytes(UTF_8))

  private def state(d: B3Probe.Driver, prefix: String): Seq[(String, Any)] = {
    val r = d.reconciled(Mv)
    Seq(
      s"$prefix.latest"        -> d.latest(Mv),
      s"$prefix.stored"        -> d.storedVersion(Mv),
      s"$prefix.reconciled"    -> r.lastVersion,
      s"$prefix.stored_wm"     -> d.stored(Mv).map(s => B3Probe.fmt(s.watermarks)).getOrElse(""),
      s"$prefix.reconciled_wm" -> B3Probe.fmt(d.watermarks(r)),
      s"$prefix.cdf"           -> B3Probe.fmt(d.cdfFor(Mv)),
      s"$prefix.marker"        -> d.markerLine(Mv),
      s"$prefix.parity"        -> d.parity(Mv, Query)
    )
  }

  def main(args: Array[String]): Unit = {
    val root    = Paths.get(args(0))
    val phase   = args(1)
    val variant = args(2)
    val spark   = B3Probe.driver(root, s"b3-gap-$phase-$variant")
    try {
      val d = new B3Probe.Driver(spark, root)
      if (phase == "crash") crash(d, root, variant) else recover(d, root, variant)
    } finally spark.stop()
  }

  private def die(root: Path, variant: String): Unit = {
    Files.write(root.resolve("crash-marker"), variant.getBytes(UTF_8))
    Runtime.getRuntime.halt(Exit)
  }

  private def crash(d: B3Probe.Driver, root: Path, variant: String): Unit = {
    d.sql(s"CREATE TABLE $Src(symbol STRING, amount INT) USING DELTA TBLPROPERTIES ('delta.enableChangeDataFeed'='true')")
    d.sql(s"INSERT INTO $Src SELECT concat('sym_', cast(id % 10 as string)), cast(id as int) FROM range(100)")
    d.sql(s"CREATE MATERIALIZED VIEW $Mv AS $Query")
    require(d.reconciled(Mv).refreshType != RefreshTypeCode.FullRefresh, "fixture MV must be incremental")
    d.delta(Src, 1)
    d.refresh(Mv, "b3g-setup")
    require(d.parity(Mv, Query), "fixture MV diverged before the crash")
    require(d.awaitFlushed(Seq(Mv)) >= 0, "setup bookkeeping did not flush")
    val setup = state(d, "setup")
    Files.write(root.resolve("receipt"), ProcessHandle.current().pid().toString.getBytes(UTF_8))
    d.delta(Src, 2)
    variant match {
      case "before_bookkeeping" =>
        B3Probe.blockFinalizer().getOrElse(sys.error("no refresh records"))
        d.refresh(Mv, "b3g-crash")
        write(root, "crash-state.txt", setup ++ state(d, "crash"))
        die(root, variant)
      case "after_version_advance" =>
        val lock = B3Probe.flushLock()
        lock.synchronized {
          d.refresh(Mv, "b3g-crash")
          val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(120)
          while (d.storedVersion(Mv) < d.latest(Mv) && System.nanoTime() < deadline) Thread.sleep(100L)
          write(root, "crash-state.txt", setup ++ state(d, "crash"))
          die(root, variant)
        }
      case other => sys.error(s"unknown variant $other")
    }
    sys.error(s"crash variant $variant did not fire")
  }

  private def recover(d: B3Probe.Driver, root: Path, variant: String): Unit = {
    require(Files.isRegularFile(root.resolve("crash-marker")), "the crash did not fire")
    require(
      new String(Files.readAllBytes(root.resolve("receipt")), UTF_8).toLong != ProcessHandle.current().pid(),
      "recovery must run in a fresh process"
    )
    val rawStored    = d.storedVersion(Mv)
    val rawStoredWm  = d.stored(Mv).map(_.watermarks).getOrElse(Map.empty[String, Long])
    val rawCdf       = d.cdfFor(Mv)
    val before       = state(d, "before")
    val latest0      = d.latest(Mv)
    val reconciled0  = d.reconciled(Mv)
    val reconciledWm = d.watermarks(reconciled0)
    d.refresh(Mv, "b3g-recover-1")
    val outcome1 = d.outcome("b3g-recover-1")
    val latest1  = d.latest(Mv)
    val parity1  = d.parity(Mv, Query)
    val after1   = state(d, "after_recover_1")
    d.refresh(Mv, "b3g-recover-2")
    val latest2 = d.latest(Mv)
    val parity2 = d.parity(Mv, Query)
    d.delta(Src, 3)
    d.refresh(Mv, "b3g-recover-3")
    val outcome3 = d.outcome("b3g-recover-3")
    val parity3  = d.parity(Mv, Query)
    val flushMs  = d.awaitFlushed(Seq(Mv))
    val after3   = state(d, "after_recover_3")
    val cdfLags  = reconciledWm.exists { case (s, v) => rawCdf.get(s).forall(_ < v) }
    val gapVisible = variant match {
      case "before_bookkeeping" =>
        rawStored < latest0 && reconciledWm.exists { case (s, v) => rawStoredWm.get(s).forall(_ < v) } && cdfLags
      case _ => rawStored == latest0 && cdfLags
    }
    val incremental = outcome3.startsWith("incremental")
    write(
      root,
      "recover-result.txt",
      before ++ after1 ++ after3 ++ Seq(
        "raw.stored"                       -> rawStored,
        "raw.stored_wm"                    -> B3Probe.fmt(rawStoredWm),
        "raw.cdf"                          -> B3Probe.fmt(rawCdf),
        "outcome.recover_1"                -> outcome1,
        "outcome.recover_3"                -> outcome3,
        "versions.recover"                 -> s"$latest0,$latest1,$latest2",
        "flush_ms"                         -> flushMs,
        "ok.gap_visible_at_restart"        -> gapVisible,
        "ok.reconciled_to_mv_log"          -> (reconciled0.lastVersion == latest0),
        "ok.no_double_apply"               -> (latest1 == latest0 && latest2 == latest1 && parity1 && parity2),
        "ok.no_lost_delta"                 -> parity1,
        "ok.incremental_after_recovery"    -> incremental,
        "ok.parity_final"                  -> parity3,
        "ok.catalog_converged_after_flush" ->
          (flushMs >= 0 && d.storedVersion(Mv) == d.latest(Mv) && d.reconciled(Mv).lastVersion == d.latest(Mv)),
        "ok.cdf_rows_caught_up"            ->
          d.watermarks(d.reconciled(Mv)).forall { case (s, v) => d.cdfFor(Mv).get(s).exists(_ >= v) }
      )
    )
  }
}

/** Fails the deferred catalog flush with read-only Delta logs, then checks the same driver and a fresh driver. */
private[common] object B3ProbeScenarioA {
  val Src   = "default.b3a_src"
  val Mv    = "default.b3a_mv"
  val Query = s"SELECT symbol, COUNT(*) AS events, SUM(amount) AS total FROM $Src GROUP BY symbol"

  private def logDir(d: B3Probe.Driver, table: String): Path =
    Paths.get(new org.apache.hadoop.fs.Path(s"${d.catalogPath}/$table/_delta_log").toUri.getPath)

  private def chmod(d: B3Probe.Driver, variant: String, perms: String): Unit =
    (if (variant == "cdf") Seq("cdf_watermarks") else Seq("cdf_watermarks", "mv_metadata")).foreach { table =>
      Files.setPosixFilePermissions(logDir(d, table), PosixFilePermissions.fromString(perms))
    }

  private def state(d: B3Probe.Driver, prefix: String): Seq[(String, Any)] = {
    val r = d.reconciled(Mv)
    Seq(
      s"$prefix.latest"        -> d.latest(Mv),
      s"$prefix.stored"        -> d.storedVersion(Mv),
      s"$prefix.reconciled"    -> r.lastVersion,
      s"$prefix.stored_wm"     -> d.stored(Mv).map(s => B3Probe.fmt(s.watermarks)).getOrElse(""),
      s"$prefix.reconciled_wm" -> B3Probe.fmt(d.watermarks(r)),
      s"$prefix.cdf"           -> B3Probe.fmt(d.cdfFor(Mv)),
      s"$prefix.marker"        -> d.markerLine(Mv),
      s"$prefix.parity"        -> d.parity(Mv, Query)
    )
  }

  private def verify(d: B3Probe.Driver, label: String): Seq[(String, Any)] = {
    val before      = state(d, s"$label.before")
    val parity0     = d.parity(Mv, Query)
    val v0          = d.latest(Mv)
    val noop        = B3Probe.attempt(d.refresh(Mv, s"b3a-$label-noop"))
    val noopOutcome = d.outcome(s"b3a-$label-noop")
    val v1          = d.latest(Mv)
    val parity1     = d.parity(Mv, Query)
    d.delta(Src, 3)
    val next        = B3Probe.attempt(d.refresh(Mv, s"b3a-$label-next"))
    val nextOutcome = d.outcome(s"b3a-$label-next")
    val parity2     = d.parity(Mv, Query)
    val flushMs     = d.awaitFlushed(Seq(Mv))
    val after       = state(d, s"$label.after")
    val r           = d.reconciled(Mv)
    before ++ after ++ Seq(
      s"$label.refresh_noop"             -> s"$noop/$noopOutcome",
      s"$label.refresh_next"             -> s"$next/$nextOutcome",
      s"$label.versions"                 -> s"$v0,$v1",
      s"$label.flush_ms"                 -> flushMs,
      s"ok.$label.parity_before_refresh" -> parity0,
      s"ok.$label.no_replay"             -> (noop == "ok" && noopOutcome.startsWith("no_pending") && v1 == v0 && parity1),
      s"ok.$label.no_skip"               -> (next == "ok" && nextOutcome.startsWith("incremental") && parity2),
      s"ok.$label.converged" ->
        (flushMs >= 0 && d.storedVersion(Mv) == d.latest(Mv) && r.lastVersion == d.latest(Mv)),
      s"ok.$label.cdf_caught_up" -> d.watermarks(r).forall { case (s, v) => d.cdfFor(Mv).get(s).exists(_ >= v) }
    )
  }

  def main(args: Array[String]): Unit = {
    val root    = Paths.get(args(0))
    val phase   = args(1)
    val variant = args(2)
    val spark   = B3Probe.driver(root, s"b3-scn-a-$phase-$variant")
    try {
      val d = new B3Probe.Driver(spark, root)
      phase match {
        case "fail" => fail(d, root, variant)
        case "fresh" =>
          val failPid = B3Probe
            .readLines(root, "fail.txt")
            .find(_.startsWith("fail.pid="))
            .map(_.stripPrefix("fail.pid=").toLong)
          require(failPid.exists(_ != B3Probe.pid), "the fresh driver must be another process")
          B3Probe.writeKv(root, "fresh.txt", Seq("fresh.pid" -> B3Probe.pid) ++ verify(d, "fresh"))
        case other => sys.error(s"unknown phase $other")
      }
    } finally spark.stop()
  }

  private def fail(d: B3Probe.Driver, root: Path, variant: String): Unit = {
    d.sql(s"CREATE TABLE $Src(symbol STRING, amount INT) USING DELTA TBLPROPERTIES ('delta.enableChangeDataFeed'='true')")
    d.sql(s"INSERT INTO $Src SELECT concat('sym_', cast(id % 10 as string)), cast(id as int) FROM range(100)")
    d.sql(s"CREATE MATERIALIZED VIEW $Mv AS $Query")
    require(d.reconciled(Mv).refreshType != RefreshTypeCode.FullRefresh, "fixture MV must be incremental")
    d.delta(Src, 1)
    d.refresh(Mv, "b3a-setup")
    require(d.parity(Mv, Query), "fixture MV diverged during setup")
    require(d.awaitFlushed(Seq(Mv)) >= 0, "setup bookkeeping did not flush")
    val setup    = state(d, "setup")
    val location = d.reconciled(Mv).location
    d.delta(Src, 2)
    chmod(d, variant, "r-xr-xr-x")
    val (refresh, idleMs, queued) =
      try {
        val result = B3Probe.attempt(d.refresh(Mv, "b3a-fail"))
        val idle   = B3Probe.awaitIdle()
        (result, idle, if (B3Probe.hasRecords) B3Probe.pendingMap.size else 0)
      } finally chmod(d, variant, "rwxr-xr-x")
    val latest     = d.latest(Mv)
    val shape      = B3Probe.commitShape(d.spark, location, latest)
    val failed     = state(d, "failed")
    val reconciled = d.reconciled(Mv)
    val cdfLags    = d.watermarks(reconciled).exists { case (s, v) => d.cdfFor(Mv).get(s).forall(_ < v) }
    val gap =
      if (variant == "cdf") d.storedVersion(Mv) == latest && cdfLags
      else d.storedVersion(Mv) < latest && reconciled.lastVersion == latest && cdfLags
    val standalone =
      shape.startsWith(s"v$latest[commitInfo:1,txn:1];") &&
        shape.split(";").lift(1).exists(s => s.contains("add:") || s.contains("remove:"))
    val same = if (variant == "both-same") verify(d, "same") else Seq.empty
    B3Probe.writeKv(
      root,
      "fail.txt",
      setup ++ failed ++ Seq(
        "fail.pid"                  -> B3Probe.pid,
        "fail.read_only"            -> (if (variant == "cdf") "cdf_watermarks" else "cdf_watermarks,mv_metadata"),
        "fail.refresh"              -> s"$refresh/${d.outcome("b3a-fail")}",
        "fail.idle_ms"              -> idleMs,
        "fail.queued_after_flush"   -> queued,
        "fail.commit_shape"         -> shape,
        "ok.fail.acknowledged"      -> (refresh == "ok"),
        "ok.fail.queue_cleared"     -> (idleMs >= 0 && queued == 0),
        "ok.fail.marker_standalone" -> standalone,
        "ok.fail.gap_visible"       -> gap
      ) ++ same
    )
  }
}

/** Replays an old driver's queued flush after another driver dropped and recreated sources of unchanged MVs. */
private[common] object B3ProbeScenarioB {
  private def t(n: String): String = s"default.b3b_$n"
  private def agg(src: String): String =
    s"SELECT symbol, COUNT(*) AS events, SUM(amount) AS total FROM $src GROUP BY symbol"
  private def proj(up: String): String = s"SELECT symbol, total FROM $up"

  val Sources: Seq[String] = Seq("i", "ii", "iii", "iv").map(c => t(s"src_$c"))
  val Mvs: Seq[(String, String)] = Seq(
    t("up_i")    -> agg(t("src_i")),
    t("down_i")  -> proj(t("up_i")),
    t("up_ii")   -> agg(t("src_ii")),
    t("down_ii") -> proj(t("up_ii")),
    t("v_iii")   -> agg(t("src_iii")),
    t("v_iv")    -> agg(t("src_iv"))
  )
  private val names                      = Mvs.map(_._1)
  private def query(name: String): String = Mvs.find(_._1 == name).map(_._2).getOrElse(sys.error(name))

  private def createSource(d: B3Probe.Driver, src: String): Unit = {
    d.sql(s"CREATE TABLE $src(symbol STRING, amount INT) USING DELTA TBLPROPERTIES ('delta.enableChangeDataFeed'='true')")
    d.sql(s"INSERT INTO $src SELECT concat('sym_', cast(id % 10 as string)), cast(id as int) FROM range(100)")
  }

  private def sourceLatest(d: B3Probe.Driver, source: String): String =
    Try(d.latest(source).toString)
      .orElse(Try {
        val location = d.spark.sql(s"DESCRIBE DETAIL $source").select("location").head().getString(0)
        DeltaTableVersion.requireLatest(d.spark, location).toString
      })
      .getOrElse("?")

  private def row(d: B3Probe.Driver, name: String): String =
    Try {
      val r      = d.reconciled(name)
      val stored = d.stored(name)
      s"stored=${d.storedVersion(name)}|reconciled=${r.lastVersion}|latest=${d.latest(name)}" +
        s"|tid=${B3Probe.tableId(d.spark, r.location)}" +
        s"|stored_tid=${stored.flatMap(_.properties.get(MvMetadata.TargetDeltaTableIdKey)).getOrElse("")}" +
        s"|stored_wm=${stored.map(s => B3Probe.fmt(s.watermarks)).getOrElse("")}" +
        s"|reconciled_wm=${B3Probe.fmt(d.watermarks(r))}|cdf=${B3Probe.fmt(d.cdfFor(name))}" +
        s"|parity=${d.parity(name, query(name))}"
    }.recover { case e => s"error:${B3Probe.oneLine(e)}" }.get

  private def snapshot(d: B3Probe.Driver, label: String): Seq[(String, Any)] =
    names.map(n => s"$label.mv.${B3Probe.short(n)}" -> row(d, n)) ++
      d.cdfRows.map { case (view, source, version) =>
        s"$label.cdf.${B3Probe.short(view)}.${B3Probe.short(source)}" -> s"$version/src_latest=${sourceLatest(d, source)}"
      }

  private def catalogState(d: B3Probe.Driver, name: String): String =
    Try {
      val s = d.stored(name)
      s"${d.storedVersion(name)}|${s.flatMap(_.properties.get(MvMetadata.TargetDeltaTableIdKey)).getOrElse("")}|" +
        s"${s.map(x => B3Probe.fmt(x.watermarks)).getOrElse("")}|${B3Probe.fmt(d.cdfFor(name))}"
    }.getOrElse("error")

  private def refreshed(d: B3Probe.Driver, name: String, id: String): String =
    s"${B3Probe.attempt(d.refresh(name, id))}/${d.outcome(id)}"

  private def incremental(result: String): Boolean = result.startsWith("ok/incremental")

  def main(args: Array[String]): Unit = {
    val root  = Paths.get(args(0))
    val phase = args(1)
    val spark = B3Probe.driver(root, s"b3-scn-b-$phase")
    try {
      val d = new B3Probe.Driver(spark, root)
      phase match {
        case "queue"  => queue(d, root)
        case "ddl"    => ddl(d, root)
        case "replay" => replay(d, root)
        case other    => sys.error(s"unknown phase $other")
      }
    } finally spark.stop()
  }

  /** Driver A: refreshes every MV with the finalizer parked, saves its queued hints and dies before flushing. */
  private def queue(d: B3Probe.Driver, root: Path): Unit = {
    Sources.foreach(createSource(d, _))
    Mvs.foreach { case (n, q) => d.sql(s"CREATE MATERIALIZED VIEW $n AS $q") }
    val types = names.map(n => s"type.${B3Probe.short(n)}" -> d.reconciled(n).refreshType)
    Sources.foreach(d.delta(_, 1))
    val settle    = names.map(n => s"settle.${B3Probe.short(n)}" -> refreshed(d, n, s"b3b-settle-${B3Probe.short(n)}"))
    val settledMs = d.awaitFlushed(names)
    val parked    = B3Probe.blockFinalizer().isDefined
    Sources.foreach(d.delta(_, 2))
    val queued  = names.map(n => s"queued.${B3Probe.short(n)}" -> refreshed(d, n, s"b3b-queue-${B3Probe.short(n)}"))
    val pending = B3Probe.pendingLines()
    Files.write(root.resolve("pending.tsv"), pending.map(_ + "\n").mkString.getBytes(UTF_8))
    B3Probe.writeKv(
      root,
      "queue.txt",
      Seq(
        "queue.pid"        -> B3Probe.pid,
        "queue.parked"     -> parked,
        "queue.settled_ms" -> settledMs,
        "queue.pending"    -> pending.size
      ) ++ types ++ settle ++ queued ++ snapshot(d, "queue") ++
        pending.zipWithIndex.map { case (l, i) => s"queue.hint.$i" -> l.replace('\t', '|') }
    )
    Runtime.getRuntime.halt(0)
  }

  /** Driver B: drops and recreates an upstream MV, a whole chain and a base source, and refreshes v_iv past A. */
  private def ddl(d: B3Probe.Driver, root: Path): Unit = {
    val before = snapshot(d, "ddl_before")
    d.spark.conf.set(FeatureGate.StreamingCheckpointArchiveUriKey, root.resolve("archive").toUri.toString)
    val steps = Seq(
      "i.drop_up"      -> B3Probe.attempt(d.sql(s"DROP MATERIALIZED VIEW ${t("up_i")}")),
      "i.down_dropped" -> String.valueOf(!d.spark.catalog.tableExists(t("down_i"))),
      "i.create_up"    -> B3Probe.attempt(d.sql(s"CREATE MATERIALIZED VIEW ${t("up_i")} AS ${query(t("up_i"))}")),
      "i.create_down"  -> B3Probe.attempt(d.sql(s"CREATE MATERIALIZED VIEW ${t("down_i")} AS ${query(t("down_i"))}")),
      "ii.drop_down"   -> B3Probe.attempt(d.sql(s"DROP MATERIALIZED VIEW ${t("down_ii")}")),
      "ii.drop_up"     -> B3Probe.attempt(d.sql(s"DROP MATERIALIZED VIEW ${t("up_ii")}")),
      "ii.create_up"   -> B3Probe.attempt(d.sql(s"CREATE MATERIALIZED VIEW ${t("up_ii")} AS ${query(t("up_ii"))}")),
      "ii.create_down" -> B3Probe.attempt(d.sql(s"CREATE MATERIALIZED VIEW ${t("down_ii")} AS ${query(t("down_ii"))}")),
      "iii.drop_src"   -> B3Probe.attempt(d.sql(s"DROP TABLE ${t("src_iii")}")),
      "iii.create_src" -> B3Probe.attempt(createSource(d, t("src_iii"))),
      "iv.delta"       -> B3Probe.attempt(d.delta(t("src_iv"), 3)),
      "iv.refresh"     -> refreshed(d, t("v_iv"), "b3b-ddl-iv")
    )
    val flushMs = d.awaitFlushed(Seq(t("v_iv")))
    val idleMs  = B3Probe.awaitIdle()
    B3Probe.writeKv(
      root,
      "ddl.txt",
      Seq("ddl.pid" -> B3Probe.pid, "ddl.flush_ms" -> flushMs, "ddl.idle_ms" -> idleMs) ++
        steps.map { case (k, v) => s"ddl.$k" -> v } ++ before ++ snapshot(d, "ddl_after")
    )
  }

  /** Driver C: releases A's queued flush unchanged, then checks every MV for skipped or replayed CDF. */
  private def replay(d: B3Probe.Driver, root: Path): Unit = {
    val hints    = B3Probe.readLines(root, "pending.tsv").filter(l => l.nonEmpty && !l.endsWith("=missing"))
    val before   = snapshot(d, "replay_before")
    val pre      = names.map(n => n -> catalogState(d, n)).toMap
    val preKeys  = d.cdfRows.map(r => (B3Probe.short(r._1), B3Probe.short(r._2))).toSet
    val replayed = if (B3Probe.hasRecords) B3Probe.replayPending(d.spark, hints) else 0
    val idleMs   = B3Probe.awaitIdle()
    val post     = names.map(n => n -> catalogState(d, n)).toMap
    val postKeys = d.cdfRows.map(r => (B3Probe.short(r._1), B3Probe.short(r._2))).toSet
    val after    = snapshot(d, "replay_after")
    def keys(s: Set[(String, String)]): String = s.toSeq.sorted.map { case (v, src) => s"$v>$src" }.mkString(",")

    val ddlLines = B3Probe.readLines(root, "ddl.txt")
    val iRecreated =
      Seq("ddl.i.drop_up=ok", "ddl.i.down_dropped=true", "ddl.i.create_up=ok", "ddl.i.create_down=ok")
        .forall(ddlLines.contains)
    val iMvs = Seq(t("up_i"), t("down_i"))
    val untouched = ((if (iRecreated) iMvs else Seq.empty) ++ Seq(t("up_ii"), t("down_ii"), t("v_iv")))
      .map(n => B3Probe.short(n) -> (pre(n) == post(n)))
    val rolled = ((if (iRecreated) Seq.empty else iMvs) :+ t("v_iii"))
      .map(n => B3Probe.short(n) -> (d.storedVersion(n) == d.latest(n)))
    val downI   = t("down_i")
    val iBefore = refreshed(d, downI, "b3b-check-i-down-before")
    val iDrop   = if (iRecreated) "ok" else B3Probe.attempt(d.sql(s"DROP MATERIALIZED VIEW $downI"))
    val iCreate =
      if (iRecreated) "ok" else B3Probe.attempt(d.sql(s"CREATE MATERIALIZED VIEW $downI AS ${query(downI)}"))
    d.delta(t("src_i"), 3)
    val iUp     = refreshed(d, t("up_i"), "b3b-check-i-up")
    val iDown   = refreshed(d, downI, "b3b-check-i-down")
    val iParity = d.parity(t("up_i"), query(t("up_i"))) && d.parity(downI, query(downI))

    d.delta(t("src_ii"), 3)
    val iiUp     = refreshed(d, t("up_ii"), "b3b-check-ii-up")
    val iiDown   = refreshed(d, t("down_ii"), "b3b-check-ii-down")
    val iiParity = d.parity(t("up_ii"), query(t("up_ii"))) && d.parity(t("down_ii"), query(t("down_ii")))

    d.delta(t("src_iii"), 3)
    val iii       = refreshed(d, t("v_iii"), "b3b-check-iii")
    val iiiParity = d.parity(t("v_iii"), query(t("v_iii")))

    d.delta(t("src_iv"), 4)
    val iv       = refreshed(d, t("v_iv"), "b3b-check-iv")
    val ivParity = d.parity(t("v_iv"), query(t("v_iv")))

    val flushMs = d.awaitFlushed(names)
    B3Probe.writeKv(
      root,
      "replay.txt",
      Seq(
        "replay.pid"                  -> B3Probe.pid,
        "replay.hints"                -> hints.size,
        "replay.replayed"             -> replayed,
        "replay.idle_ms"              -> idleMs,
        "replay.cdf_keys_added"       -> keys(postKeys -- preKeys),
        "replay.cdf_keys_removed"     -> keys(preKeys -- postKeys),
        "check.i.down_before_recreate" -> iBefore,
        "check.i.drop_down"           -> iDrop,
        "check.i.create_down"         -> iCreate,
        "check.i.up"                  -> iUp,
        "check.i.down"                -> iDown,
        "check.i.parity"              -> iParity,
        "check.ii.up"                 -> iiUp,
        "check.ii.down"               -> iiDown,
        "check.ii.parity"             -> iiParity,
        "check.iii.v"                 -> iii,
        "check.iii.parity"            -> iiiParity,
        "check.iv.v"                  -> iv,
        "check.iv.parity"             -> ivParity,
        "check.final_flush_ms"        -> flushMs,
        "ok.replay.applied"           -> (replayed == hints.size && idleMs >= 0),
        "ok.replay.recreated_and_newer_untouched" -> untouched.forall(_._2),
        "ok.replay.unchanged_rolled_forward"      -> rolled.forall(_._2),
        "check.i.upstream_recreated"  -> iRecreated,
        "ok.i.cascade_recreated"      -> iRecreated,
        "ok.i.down_no_replay"         -> (!iRecreated || iBefore.startsWith("ok/no_pending")),
        "ok.i.recovered"              -> (iDrop == "ok" && iCreate == "ok" && incremental(iUp) && incremental(iDown) && iParity),
        "ok.ii.recovered"             -> (incremental(iiUp) && incremental(iiDown) && iiParity),
        "ok.iv.recovered"             -> (incremental(iv) && ivParity),
        "ok.final.converged"          -> (flushMs >= 0)
      ) ++ untouched.map { case (n, ok) => s"replay.untouched.$n" -> ok } ++
        rolled.map { case (n, ok) => s"replay.rolled.$n" -> ok } ++ before ++ after ++ snapshot(d, "final")
    )
  }
}

class B3ScenarioAProbeSpec extends AnyFunSpec with Matchers {
  import B3Probe._

  private val out = probeTarget.resolve(s"b3-probe-scnA-$probeTag.txt")
  Files.deleteIfExists(out)

  private def run(variant: String, phases: Seq[String]): Unit = {
    val root = probeRoot(s"scna-$variant")
    val main = "org.openivm.spark.common.B3ProbeScenarioA"
    val rcs  = phases.map(phase => phase -> launch(root, main, Seq(root.toString, phase, variant), phase))
    val lines = phases.flatMap(phase => readLines(root, s"$phase.txt").map(l => s"$phase|$l"))
    appendTo(out, Seq(s"[scnA $variant] root=$root rc=${rcs.mkString(",")}") ++ lines)
    rcs.map(_._2) shouldBe phases.map(_ => Some(0))
    if (hasRecords) lines.filter(_.contains("|ok.")).filterNot(_.endsWith("=true")) shouldBe empty
  }

  describe("lane B3 failed deferred flush") {
    it("keeps a fresh driver correct after a failed watermark flush")(run("cdf", Seq("fail", "fresh")))
    it("keeps a fresh driver correct after a failed catalog and watermark flush")(run("both", Seq("fail", "fresh")))
    it("keeps the same driver correct after a failed catalog and watermark flush")(run("both-same", Seq("fail")))
  }
}

class B3ScenarioBProbeSpec extends AnyFunSpec with Matchers {
  import B3Probe._

  describe("lane B3 queued flush across drivers") {
    it("releases an old driver's queued flush after another driver recreates sources") {
      val out = probeTarget.resolve(s"b3-probe-scnB-$probeTag.txt")
      Files.deleteIfExists(out)
      val root   = probeRoot("scnb")
      val main   = "org.openivm.spark.common.B3ProbeScenarioB"
      val phases = Seq("queue", "ddl", "replay")
      val rcs    = phases.map(phase => phase -> launch(root, main, Seq(root.toString, phase), phase))
      val lines  = phases.flatMap(phase => readLines(root, s"$phase.txt").map(l => s"$phase|$l"))
      appendTo(out, Seq(s"[scnB] root=$root rc=${rcs.mkString(",")}") ++ lines)
      rcs.map(_._2) shouldBe phases.map(_ => Some(0))
      if (hasRecords) lines.filter(_.contains("|ok.")).filterNot(_.endsWith("=true")) shouldBe empty
    }
  }
}

class B3RefreshRecordProbeSpec extends AnyFunSpec with Matchers {
  import B3Probe._

  private val target = Paths.get("target").toAbsolutePath
  private val tag    = s"${org.apache.spark.SPARK_VERSION}-${if (hasRecords) "candidate" else "baseline"}"

  private def newRoot(name: String): Path = {
    val root = target.resolve(s"b3-probe-$name-${UUID.randomUUID().toString.take(8)}")
    Files.createDirectories(root)
    root
  }

  private def append(file: Path, lines: Seq[String]): Unit =
    Files.write(file, (lines.mkString("\n") + "\n").getBytes(UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND)

  describe("lane B3 refresh records") {
    it("keeps external catalog writes, survives a recreated catalog and ignores foreign MV commits") {
      val root   = newRoot("ext")
      val out    = target.resolve(s"b3-probe-$tag.txt")
      val checks = scala.collection.mutable.ArrayBuffer.empty[(String, Boolean)]
      Files.deleteIfExists(out)
      def check(name: String, ok: Boolean): Unit = { checks += (name -> ok); append(out, Seq(s"check|$name|$ok")) }
      def info(name: String, value: Any): Unit   = append(out, Seq(s"info|$name|$value"))
      append(out, Seq(s"root=$root", s"spark=${org.apache.spark.SPARK_VERSION}", s"refresh_records=$hasRecords"))
      val spark = driver(root, "b3-probe")
      try {
        val d     = new Driver(spark, root)
        val names = Views.map(_._1)
        d.sql(
          s"CREATE TABLE $Src(symbol STRING, amount INT) USING DELTA TBLPROPERTIES ('delta.enableChangeDataFeed'='true')"
        )
        d.sql(s"INSERT INTO $Src SELECT concat('sym_', cast(id % 10 as string)), cast(id as int) FROM range(100)")
        Views.foreach { case (n, q) => d.sql(s"CREATE MATERIALIZED VIEW $n AS $q") }
        append(out, names.map(n => s"refresh_type|${short(n)}|${d.reconciled(n).refreshType}"))
        var step = 0
        def round(label: String, strict: Boolean = true): Unit = {
          step += 1
          d.delta(Src, step)
          val outcomes = names.map { n =>
            val id = s"b3p-$step-${short(n)}"
            short(n) -> Try(d.refresh(n, id)).map(_ => d.outcome(id)).recover { case e => s"error:${e.getMessage}" }.get
          }
          append(out, outcomes.map { case (n, o) => s"outcome|$step|$n|${o.take(300).replace('\n', ' ')}" })
          val incremental = outcomes.forall { case (_, o) => o.startsWith("incremental") }
          if (strict) check(s"$label.incremental", incremental) else info(s"$label.incremental", incremental)
          check(s"$label.parity", Views.forall { case (n, q) => d.parity(n, q) })
        }
        def settle(label: String): Unit = {
          val ms = d.awaitFlushed(names)
          append(out, Seq(s"flush|$label|ms=$ms"))
          check(s"$label.flushed", ms >= 0)
        }
        def converged(label: String): Unit =
          check(
            s"$label.converged",
            names.forall(n => d.storedVersion(n) == d.latest(n) && d.reconciled(n).lastVersion == d.latest(n))
          )
        def ext(cmd: String, args: String*): Unit = {
          val rc = launch(
            root,
            "org.openivm.spark.common.B3ProbeExternal",
            Seq(root.toString, d.catalogPath, cmd) ++ args,
            s"external-$cmd-${System.nanoTime()}"
          )
          append(out, Seq(s"external|$cmd|${args.mkString(",")}|rc=$rc"))
          check(s"external.$cmd.${args.headOption.getOrElse("")}.rc", rc.contains(0))
        }
        def extOn(tagValue: String, which: Seq[String]): Boolean =
          which.forall(n => d.stored(n).exists(_.properties.get("ext_drv").contains(tagValue)))
        def foreignRowKept: Boolean = d.cdfRows.contains(("b3p_foreign", "b3p_foreign_src", 42L))

        round("round1")
        settle("round1")
        converged("round1")
        val listed = MvCatalog.list(spark).map(m => short(m.name.table)).sorted
        val looked = names.map(n =>
          short(MvCatalog.lookup(spark, spark.sessionState.sqlParser.parseTableIdentifier(n)).get.name.table)
        )
        val viaSource = MvCatalog.viewsForSource(spark, Src).map(m => short(m.name.table)).sorted
        append(
          out,
          Seq(s"warm|list=${listed.mkString(",")}|lookup=${looked.mkString(",")}|views_for_source=${viaSource.mkString(",")}")
        )
        check("warm.list", listed == names.map(short).sorted)
        check("warm.views_for_source", viaSource == names.map(short).sorted)
        append(out, d.dump("warm"))
        val idsBefore = (d.catalogTableId("mv_metadata"), d.catalogTableId("cdf_watermarks"))

        ext("update")
        append(out, d.dump("after-external-commits"))
        check("external.update.visible", extOn("e1", Seq("default.b3p_v1")))
        check(
          "external.update.reconciled_visible",
          d.reconciled("default.b3p_v1").properties.get("ext_drv").contains("e1")
        )
        check("external.update.foreign_row_visible", foreignRowKept)
        round("round2")
        settle("round2")
        append(out, d.dump("advance-past-external"))
        check("round2.ext_drv_kept", extOn("e1", Seq("default.b3p_v1")))
        check("round2.foreign_row_kept", foreignRowKept)
        converged("round2")

        ext("recreate", "r")
        append(out, d.dump("after-external-recreate"))
        val idsRecreated = (d.catalogTableId("mv_metadata"), d.catalogTableId("cdf_watermarks"))
        check("recreate.new_table_ids", idsRecreated._1 != idsBefore._1 && idsRecreated._2 != idsBefore._2)
        check("recreate.visible", extOn("r", names))
        round("round3")
        settle("round3")
        append(out, d.dump("advance-past-external-recreate"))
        check("round3.ext_drv_kept", extOn("r", names))
        check("round3.foreign_row_kept", foreignRowKept)
        converged("round3")

        val gate = blockFinalizer()
        round("round4")
        append(out, d.dump("pending-before-recreate"))
        if (gate.isDefined) {
          append(out, names.map(n => s"marker|${short(n)}|${d.markerLine(n)}"))
          check("round4.stored_lags_while_pending", names.forall(n => d.storedVersion(n) < d.latest(n)))
          check("round4.reconciled_from_mv_log", names.forall(n => d.reconciled(n).lastVersion == d.latest(n)))
          check("round4.marker_in_mv_log", names.forall(n => d.markerTags(n).get("openivm.refresh").contains("v1")))
        }
        val idsBeforeSecond = (d.catalogTableId("mv_metadata"), d.catalogTableId("cdf_watermarks"))
        ext("recreate", "r2")
        gate.foreach(_.countDown())
        settle("round4")
        append(out, d.dump("flush-after-recreate"))
        val idsSecond = (d.catalogTableId("mv_metadata"), d.catalogTableId("cdf_watermarks"))
        check("round4.new_table_ids", idsSecond._1 != idsBeforeSecond._1 && idsSecond._2 != idsBeforeSecond._2)
        check("round4.ext_drv_kept", extOn("r2", names))
        check("round4.foreign_row_kept", foreignRowKept)
        converged("round4")

        val pre = names.map(n => n -> (d.storedVersion(n), d.latest(n))).toMap
        ext("foreign", d.reconciled("default.b3p_v1").location, d.reconciled("default.b3p_v2").location)
        append(
          out,
          names.map(n =>
            s"foreign|${short(n)}|stored=${d.storedVersion(n)}|reconciled=${d.reconciled(n).lastVersion}|latest=${d.latest(n)}"
          )
        )
        check("foreign.committed", Seq("default.b3p_v1", "default.b3p_v2").forall(n => d.latest(n) > pre(n)._2))
        check("foreign.ignored_by_reconcile", names.forall(n => d.reconciled(n).lastVersion == pre(n)._1))
        check("foreign.parity_unchanged", Views.forall { case (n, q) => d.parity(n, q) })
        round("round5", strict = false)
        settle("round5")
        append(out, d.dump("advance-past-foreign"))
        converged("round5")
        round("round6", strict = false)
        settle("round6")
        append(out, d.dump("final"))
        converged("round6")
        check("final.ext_drv_kept", extOn("r2", names))
        check("final.foreign_row_kept", foreignRowKept)
      } finally spark.stop()
      append(out, Seq(s"failed_checks=${checks.filterNot(_._2).map(_._1).mkString(",")}"))
      checks.filterNot(_._2).map(_._1) shouldBe empty
    }

    Seq("before_bookkeeping", "after_version_advance").foreach { variant =>
      it(s"recovers a driver killed $variant from the MV log") {
        assume(hasRecords, "baseline has no refresh records")
        val root    = newRoot(s"gap-$variant")
        val out     = target.resolve(s"b3-probe-gap-$tag.txt")
        val crash   = launch(root, "org.openivm.spark.common.B3ProbeGap", Seq(root.toString, "crash", variant), "crash")
        val recover = launch(root, "org.openivm.spark.common.B3ProbeGap", Seq(root.toString, "recover", variant), "recover")
        def lines(file: String): Seq[String] =
          if (Files.isRegularFile(root.resolve(file))) Files.readAllLines(root.resolve(file), UTF_8).asScala.toSeq
          else Seq(s"$file=missing")
        val result = lines("recover-result.txt")
        append(
          out,
          Seq(s"[gap $variant] root=$root crash_rc=$crash recover_rc=$recover") ++
            lines("crash-state.txt").map("crash|" + _) ++ result.map("recover|" + _)
        )
        crash shouldBe Some(B3ProbeGap.Exit)
        recover shouldBe Some(0)
        result.filter(_.startsWith("ok.")).filterNot(_.endsWith("=true")) shouldBe empty
        result.count(_.startsWith("ok.")) shouldBe 9
      }
    }
  }
}
