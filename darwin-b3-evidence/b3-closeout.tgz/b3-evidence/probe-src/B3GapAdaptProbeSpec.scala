package org.openivm.spark.common.rocksdb

import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.apache.hadoop.fs.{FileStatus, LocalFileSystem, Path => HadoopPath}
import org.apache.spark.sql.SparkSession
import org.openivm.spark.common.{
  CdfWatermarkCatalog,
  ChangeWatermark,
  DeltaTableVersion,
  FeatureGate,
  GroupCommitDeltaCdfWatermarkBackend,
  MvCatalog,
  MvMetadata,
  RefreshTypeCode
}
import org.openivm.spark.perf.{StateGuardPerfTag, StateGuardReport}
import org.openivm.spark.telemetry.BoundedTelemetryRuntime
import org.openivm.spark.testkit.TestPools
import org.scalatest.funspec.AnyFunSpec
import org.scalatest.matchers.should.Matchers

import java.lang.management.ManagementFactory
import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.{Files, Path, Paths}
import java.util.UUID
import java.util.concurrent.TimeUnit
import scala.concurrent.duration._
import scala.concurrent.{Await, Future}
import scala.jdk.CollectionConverters._

/** Out-of-diff B3 adaptation of the 742 `mv_version_and_cdf_watermark_gap` crash point. The 742 hook keys on the
  * synchronous `postRefreshCleanup -> CdfChangePropagation.markConsumed` stack, which B3 moves to the post-ack
  * deferred flush. These hooks kill the JVM inside that flush instead:
  *   - gap_flush_between_catalogs: after the mv_metadata advance, before the cdf_watermarks write (742's gap shape)
  *   - gap_flush_before_catalogs: before either catalog write (only the MV-log refresh record is durable)
  */
class B3GapFileSystem extends LocalFileSystem {
  private def beforeRead(path: HadoopPath): Unit = {
    val hook = B3GapCrashProbe.hook
    val want = B3GapCrashProbe.pathFragment
    if (hook != null && want != null && path.toString.contains(want)) {
      val stack = Thread.currentThread().getStackTrace.toVector
      if (
        stack.exists(_.getClassName.contains("MvRefreshRecords")) &&
        stack.exists(_.getMethodName == B3GapCrashProbe.methodName)
      ) {
        B3GapCrashProbe.hook = null
        hook()
      }
    }
  }

  override def getFileStatus(path: HadoopPath): FileStatus     = { beforeRead(path); super.getFileStatus(path) }
  override def listStatus(path: HadoopPath): Array[FileStatus] = { beforeRead(path); super.listStatus(path) }
}

private[rocksdb] object B3GapCrashProbe {
  val CrashExit = 73

  val Between                         = "gap_flush_between_catalogs"
  val Before                          = "gap_flush_before_catalogs"
  @volatile var hook: (() => Unit)    = _
  @volatile var pathFragment: String  = _
  @volatile var methodName: String    = _
  @volatile var hookThread: String    = _

  private val source = "default.sgcrash_events"
  private val mv     = "default.sgcrash_mv"
  private val query  = s"SELECT symbol, COUNT(*) AS events, SUM(amount) AS total FROM $source GROUP BY symbol"

  private final class Fixture(spark: SparkSession, root: Path) {
    private val mapper = new ObjectMapper()

    def sql(text: String): Unit   = { spark.sql(text).collect(); () }
    def metadata                  = MvCatalog.lookup(spark, spark.sessionState.sqlParser.parseTableIdentifier(mv)).get
    def storedMetadata            = MvCatalog.lookupStored(spark, spark.sessionState.sqlParser.parseTableIdentifier(mv))
    def mvVersion(): Long         = DeltaTableVersion.requireLatest(spark, metadata.location)
    def sourceVersion(): Long     = spark.sql(s"DESCRIBE HISTORY $source LIMIT 1").head().getLong(0)
    def watermark(): Option[Long] = CdfWatermarkCatalog.get(spark, mv, metadata.sourceTables.head)
    def durableWatermark(): Option[Long] =
      GroupCommitDeltaCdfWatermarkBackend.get(spark, mv, metadata.sourceTables.head)

    private def persisted(meta: MvMetadata): Option[Long] =
      meta.properties
        .get(s"${MvMetadata.WatermarkKeyPrefix}${meta.sourceTables.head}")
        .flatMap(ChangeWatermark.decodeDeltaVersion)
        .map(_.version)

    /** 742's requireCdfGap, verbatim except for the watermark reader: in the crash JVM the API merges the queued
      * flush, so the separate watermark table is read through the durable backend. In the recovery JVM the queue is
      * empty and the API is used unchanged. */
    def requireCdfGap(beforeMv: Long, beforeWatermark: Long, pendingVersion: Long, durable: Boolean): String = {
      val meta = metadata
      require(mvVersion() > beforeMv && converged(), "MV data and catalog advance must commit before the crash")
      val wm = if (durable) durableWatermark() else watermark()
      require(wm.contains(beforeWatermark), s"the separate CDF watermark advanced before the crash: $wm")
      require(persisted(meta).contains(pendingVersion), "MV metadata did not durably record the applied CDF version")
      require(parity(), "MV data diverged before the watermark crash")
      val stored = storedMetadata
      s"latest=${mvVersion()} reconciled_last=${meta.lastVersion} stored_last=${stored.map(_.lastVersion)} " +
        s"stored_wm_prop=${stored.flatMap(persisted)} reconciled_wm_prop=${persisted(meta)} api_wm=${watermark()} " +
        s"durable_wm=${durableWatermark()} thread=$hookThread"
    }

    def parity(): Boolean = {
      val actual   = spark.sql(s"SELECT symbol, events, total FROM $mv")
      val expected = spark.sql(query)
      actual.exceptAll(expected).count() == 0L && expected.exceptAll(actual).count() == 0L
    }

    def converged(): Boolean = {
      val meta = metadata
      meta.lastVersion == DeltaTableVersion.requireLatest(spark, meta.location)
    }

    def delta(step: Int): Unit = {
      sql(
        s"INSERT INTO $source SELECT concat('sym_', cast(id % 10 as string)), cast(${step * 1000} + id as int) " +
          "FROM range(20)"
      )
      sql(s"DELETE FROM $source WHERE symbol = 'sym_${step % 10}' AND amount % 2 = 0")
    }

    def refresh(requestId: String): Unit = {
      spark.sparkContext.setLocalProperty("openivm.request_id", requestId)
      try sql(s"REFRESH MATERIALIZED VIEW $mv")
      finally spark.sparkContext.setLocalProperty("openivm.request_id", null)
    }

    def outcome(requestId: String): String = {
      BoundedTelemetryRuntime.awaitDrain(10000L)
      val files = Files.list(root.resolve("phase-events"))
      val nodes =
        try
          files
            .iterator()
            .asScala
            .filter(_.getFileName.toString.endsWith(".jsonl"))
            .flatMap(file => Files.readAllLines(file, UTF_8).asScala.map(line => mapper.readTree(line)))
            .toVector
        finally files.close()
      nodes
        .find(n =>
          n.path("request_id").asText() == requestId && n.path("operation").asText() == "refresh" &&
            n.has("effective_refresh_type")
        )
        .map(_.path("outcome").asText())
        .getOrElse("missing")
    }
  }

  def main(args: Array[String]): Unit = {
    val root    = Paths.get(args(0))
    val phase   = args(1)
    val point   = args(2)
    val backend = args(3)
    val spark = SparkSession
      .builder()
      .master("local[1]")
      .appName(s"b3-gap-$phase-$point")
      .config("spark.ui.enabled", "false")
      .config("spark.plugins", "org.openivm.spark.plugin.metrics.OpenIvmMetricsPlugin")
      .config("spark.openivm.telemetry.queue.enabled", "true")
      .config("spark.openivm.telemetry.queue.localUri", root.resolve("phase-events").toUri.toString)
      .config("spark.driver.host", "localhost")
      .config("spark.driver.bindAddress", "127.0.0.1")
      .config("spark.sql.shuffle.partitions", "1")
      .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension,org.openivm.spark.OpenIvmSparkExtensions"
      )
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.catalogImplementation", "hive")
      .config("spark.hadoop.javax.jdo.option.ConnectionURL", s"jdbc:derby:;databaseName=$root/metastore;create=true")
      .config("spark.sql.warehouse.dir", root.resolve("warehouse").toString)
      .config("spark.hadoop.fs.file.impl", classOf[B3GapFileSystem].getName)
      .config("spark.hadoop.fs.file.impl.disable.cache", "true")
      .config(FeatureGate.EnabledKey, "true")
      .config(FeatureGate.ChangeFeedModeKey, "cdf")
      .config(FeatureGate.QueryLogEnabledKey, "true")
      .config(FeatureGate.CatalogBackendKey, backend)
      .config(FeatureGate.StatePathKey, root.resolve("state").toString)
      .config(FeatureGate.StateSyncUriKey, root.resolve("remote").toUri.toString)
      .config(FeatureGate.StateSyncAsyncEnabledKey, "false")
      .config(FeatureGate.GcEnabledKey, "false")
      .getOrCreate()
    try {
      val fixture = new Fixture(spark, root)
      if (phase == "crash") crash(fixture, root, point) else recover(fixture, root, point)
    } finally spark.stop()
  }

  private def die(root: Path, point: String): Unit = {
    Files.write(root.resolve("crash-marker"), point.getBytes(UTF_8))
    Runtime.getRuntime.halt(CrashExit)
  }

  private def crash(f: Fixture, root: Path, point: String): Unit = {
    f.sql(s"CREATE TABLE $source(symbol STRING, amount INT) USING DELTA TBLPROPERTIES ('delta.enableChangeDataFeed'='true')")
    f.sql(s"INSERT INTO $source SELECT concat('sym_', cast(id % 10 as string)), cast(id as int) FROM range(100)")
    f.sql(s"CREATE MATERIALIZED VIEW $mv AS $query")
    require(f.metadata.refreshType != RefreshTypeCode.FullRefresh, "fixture MV must be incremental")
    f.delta(1)
    f.refresh("sgcrash-setup")
    require(f.parity(), "fixture MV diverged before the crash")
    // Let the setup refresh's deferred flush land before arming the hook.
    Thread.sleep(30000L)
    Files.write(root.resolve("receipt"), ProcessHandle.current().pid().toString.getBytes(UTF_8))
    f.delta(2)
    val beforeMv        = f.mvVersion()
    val beforeWatermark = f.watermark().get
    val pendingVersion  = f.sourceVersion()
    require(f.durableWatermark().contains(beforeWatermark), "setup flush did not land")
    require(pendingVersion > beforeWatermark, "the crash must interrupt a nonempty CDF batch")
    Files.write(
      root.resolve("gap-receipt"),
      Seq(beforeMv.toString, beforeWatermark.toString, pendingVersion.toString).asJava,
      UTF_8
    )
    point match {
      case Between => pathFragment = "/cdf_watermarks"; methodName = "putAllViews"
      case Before  => pathFragment = "/mv_metadata"; methodName = "advanceRecorded"
      case other   => sys.error(s"unknown crash point $other")
    }
    hook = () => {
      hookThread = Thread.currentThread().getName
      val state = f.requireCdfGap(beforeMv, beforeWatermark, pendingVersion, durable = true)
      Files.write(root.resolve("crash-state"), state.getBytes(UTF_8))
      die(root, point)
    }
    f.refresh("sgcrash-crash")
    Files.write(root.resolve("acked"), "true".getBytes(UTF_8))
    val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(120)
    while (System.nanoTime() < deadline) Thread.sleep(100L)
    sys.error(s"crash point $point did not fire")
  }

  private def recover(f: Fixture, root: Path, point: String): Unit = {
    require(Files.isRegularFile(root.resolve("crash-marker")), "the crash hook was not reached")
    require(Files.isRegularFile(root.resolve("acked")), "the crash must follow the refresh acknowledgment")
    require(
      new String(Files.readAllBytes(root.resolve("receipt")), UTF_8).toLong != ProcessHandle.current().pid(),
      "recovery must run in a fresh process"
    )
    val meta = f.metadata
    require(meta.refreshType != RefreshTypeCode.FullRefresh, "recovered MV lost its incremental refresh type")
    val beforeRecovery = f.mvVersion()
    val saved          = Files.readAllLines(root.resolve("gap-receipt"), UTF_8).asScala.map(_.toLong)
    val recoverState   = f.requireCdfGap(saved(0), saved(1), saved(2), durable = false)
    f.refresh("sgcrash-recover-1")
    val afterRecovery = f.mvVersion()
    val recoveredOk   = f.parity() && f.converged()
    f.refresh("sgcrash-recover-2")
    val retryClean = f.mvVersion() == afterRecovery && f.parity()
    f.delta(3)
    f.refresh("sgcrash-recover-3")
    val outcome     = f.outcome("sgcrash-recover-3")
    val incremental = outcome != "missing" && outcome.nonEmpty && !outcome.contains("full_refresh")
    val finalOk     = f.parity() && f.converged()
    val ackedKept   = afterRecovery == beforeRecovery
    Thread.sleep(30000L)
    val flushed = f.storedMetadata.map(_.lastVersion).contains(f.mvVersion()) &&
      f.durableWatermark() == f.watermark()

    val result = new java.util.LinkedHashMap[String, AnyRef]()
    result.put("crash_state", new String(Files.readAllBytes(root.resolve("crash-state")), UTF_8))
    result.put("recover_state", recoverState)
    result.put("mv_version_before_recovery", java.lang.Long.valueOf(beforeRecovery))
    result.put("mv_version_after_recovery", java.lang.Long.valueOf(afterRecovery))
    result.put("recover1_outcome", f.outcome("sgcrash-recover-1"))
    result.put("recover2_outcome", f.outcome("sgcrash-recover-2"))
    result.put("parity", java.lang.Boolean.valueOf(recoveredOk && finalOk))
    result.put("metadata_converged", java.lang.Boolean.valueOf(recoveredOk && finalOk))
    result.put("no_double_apply", java.lang.Boolean.valueOf(ackedKept && retryClean))
    result.put("incremental_after_recovery", java.lang.Boolean.valueOf(incremental && retryClean && ackedKept))
    result.put("catalogs_flushed_after_recovery", java.lang.Boolean.valueOf(flushed))
    result.put("recovery_outcome", outcome)
    Files.write(root.resolve("recover-result.json"), new ObjectMapper().writeValueAsBytes(result))
  }
}

class B3GapAdaptProbeSpec extends AnyFunSpec with Matchers {
  private def launch(root: Path, phase: String, point: String, backend: String): Option[Int] = {
    val java = Paths.get(System.getProperty("java.home"), "bin", "java").toString
    val modules = ManagementFactory.getRuntimeMXBean.getInputArguments.asScala
      .filter(arg => arg.startsWith("--add-opens=") || arg.startsWith("--add-exports="))
    val process = new ProcessBuilder(
      (Seq(java, "-Xmx2g") ++ modules ++ Seq(
        "-cp",
        System.getProperty("java.class.path"),
        "org.openivm.spark.common.rocksdb.B3GapCrashProbe",
        root.toString,
        phase,
        point,
        backend
      )): _*
    ).redirectErrorStream(true).redirectOutput(root.resolve(s"$phase.log").toFile).start()
    try if (process.waitFor(400, TimeUnit.SECONDS)) Some(process.exitValue()) else None
    finally if (process.isAlive) process.destroyForcibly()
  }

  private def runPoint(point: String, rep: Int, backend: String): Map[String, Any] = {
    val root = Paths.get("target").toAbsolutePath.resolve(s"b3-gap-$point-$rep-${UUID.randomUUID().toString.take(8)}")
    Files.createDirectories(root)
    val crashExit = launch(root, "crash", point, backend)
    val crashed   = crashExit.contains(B3GapCrashProbe.CrashExit) && Files.isRegularFile(root.resolve("crash-marker"))
    val result: Option[JsonNode] =
      if (!crashed) None
      else {
        val exit = launch(root, "recover", point, backend)
        val file = root.resolve("recover-result.json")
        if (exit.contains(0) && Files.isRegularFile(file)) Some(new ObjectMapper().readTree(file.toFile)) else None
      }
    Map[String, Any](
      "name"    -> point,
      "rep"     -> rep,
      "crashed" -> crashed,
      "exit"    -> crashExit.map(_.toString).getOrElse("timeout"),
      "root"    -> root.toString,
      "result"  -> result.map(_.toString).getOrElse("none")
    )
  }

  it("B3 deferred-flush gap crash points recover without replay or loss", StateGuardPerfTag) {
    val backend = StateGuardReport.catalogBackend
    val reps    = sys.props.getOrElse("b3.gap.reps", "2").toInt
    val work    = for { p <- Seq(B3GapCrashProbe.Between, B3GapCrashProbe.Before); r <- 1 to reps } yield (p, r)
    val reports = TestPools.withPool(work.size) { implicit ec =>
      Await.result(Future.sequence(work.map { case (p, r) => Future(runPoint(p, r, backend)) }), 60.minutes)
    }
    val text = reports.map(_.map { case (k, v) => s"$k=$v" }.mkString(" | ")).mkString("\n")
    Files.write(Paths.get("target").toAbsolutePath.resolve("b3-gap-adapt.txt"), (s"backend=$backend\n" + text).getBytes(UTF_8))
    val mapper = new ObjectMapper()
    val failing = reports.filterNot { r =>
      r("crashed") == true && r("result") != "none" && {
        val n = mapper.readTree(r("result").toString)
        Seq("parity", "metadata_converged", "no_double_apply", "incremental_after_recovery", "catalogs_flushed_after_recovery")
          .forall(n.path(_).asBoolean(false))
      }
    }
    withClue(text) { failing shouldBe empty }
  }
}
