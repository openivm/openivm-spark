package org.openivm.spark.perf

import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import org.openivm.spark.common.{FeatureGate, MvCatalog, RefreshSqlLogAsyncFlusher}
import org.openivm.spark.parity.base.{CdfMode, IvmParitySpecBase}
import org.openivm.spark.telemetry.BoundedTelemetryQueue
import org.openivm.spark.testkit.TestPools

import java.io.File
import java.net.URI
import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Paths, StandardOpenOption}
import java.util.UUID
import java.util.concurrent.{ConcurrentHashMap, ScheduledExecutorService, TimeUnit}
import scala.concurrent.duration._
import scala.concurrent.{Await, Future}
import scala.jdk.CollectionConverters._
import scala.util.Try

/** Out-of-diff latency probe for lane B3 (never committed). Local modeled latency only; not OneLake. */
private[perf] object B3Records {
  private lazy val module: Option[(Class[AnyRef], AnyRef)] =
    Try {
      val cls = Class.forName("org.openivm.spark.common.MvRefreshRecords$")
      (cls.asInstanceOf[Class[AnyRef]], cls.getField("MODULE$").get(null))
    }.toOption

  def present: Boolean = module.isDefined

  private def pending: ConcurrentHashMap[AnyRef, AnyRef] = {
    val (cls, instance) = module.get
    val field = cls.getDeclaredFields
      .find(f => f.getName == "pending" || f.getName.endsWith("$$pending"))
      .getOrElse(sys.error("pending not found"))
    field.setAccessible(true)
    field.get(instance).asInstanceOf[ConcurrentHashMap[AnyRef, AnyRef]]
  }

  private def executor: ScheduledExecutorService = {
    val (cls, instance) = module.get
    val method = cls.getDeclaredMethods
      .find(m => (m.getName == "executor" || m.getName.endsWith("$$executor")) && m.getParameterCount == 0)
      .getOrElse(sys.error("executor not found"))
    method.setAccessible(true)
    method.invoke(instance).asInstanceOf[ScheduledExecutorService]
  }

  def pendingCount: Int = if (present) pending.size() else 0

  /** Nanoseconds from `fromNs` until no record is queued and the finalizer thread has drained; -1 on timeout. */
  def awaitIdle(fromNs: Long, timeoutMs: Long = 300000L): Long =
    if (!present) 0L
    else {
      val deadline = System.nanoTime() + timeoutMs * 1000000L
      while (!pending.isEmpty && System.nanoTime() < deadline) Thread.sleep(5L)
      executor.submit(new Runnable { override def run(): Unit = () }).get(timeoutMs, TimeUnit.MILLISECONDS)
      if (pending.isEmpty) System.nanoTime() - fromNs else -1L
    }
}

private[perf] final case class B3Batch(ids: Seq[String], startNs: Long, submit: Seq[Long], ack: Seq[Long], ackEpoch: Seq[Long])

abstract class B3LatencyProbeBase(slug: String, prefix: String, variant: String)
    extends IvmParitySpecBase(slug)
    with CdfMode {

  private val MvCount = 6
  private val workDir = new File(s"target/$prefix-${UUID.randomUUID().toString.take(8)}").getAbsoluteFile
  private val remote  = new File(workDir, "state-sync-remote")
  private val queue   = new File(workDir, "telemetry-queue")
  private val mapper  = new ObjectMapper()
  private val build   = if (B3Records.present) "candidate" else "baseline"
  private val out =
    Paths.get("target").toAbsolutePath.resolve(s"b3-latency-$variant-${org.apache.spark.SPARK_VERSION}-$build.txt")

  workDir.mkdirs(); remote.mkdirs(); queue.mkdirs()

  override protected def sparkMaster: String = "local[8]"

  override protected def extraSparkConf: Map[String, String] = Map(
    "spark.plugins"                      -> "org.openivm.spark.plugin.metrics.OpenIvmMetricsPlugin",
    BoundedTelemetryQueue.EnabledKey     -> "true",
    BoundedTelemetryQueue.LocalUriKey    -> queue.toURI.toString,
    BoundedTelemetryQueue.CapacityKey    -> "65536",
    FeatureGate.CatalogBackendKey        -> "delta",
    FeatureGate.StateSyncUriKey          -> remote.toURI.toString,
    FeatureGate.StateSyncAsyncEnabledKey -> "false",
    FeatureGate.ProfileRefreshKey        -> "true",
    FeatureGate.QueryLogEnabledKey       -> "true",
    "fs.file.impl"                       -> classOf[StateGuardLocalFileSystem].getName,
    "fs.file.impl.disable.cache"         -> "true",
    "fs.AbstractFileSystem.file.impl"    -> classOf[StateGuardLocalAbstractFs].getName
  )

  override def afterAll(): Unit =
    try { StateGuardFsInjection.disable(); StateGuardFsInjection.reset() }
    finally super.afterAll()

  private def src: String          = s"${prefix}_events"
  private def mv(i: Int): String   = s"${prefix}_mv$i"
  private def expected(i: Int)     = s"SELECT symbol, COUNT(*) AS events, SUM(amount * $i) AS total FROM $src GROUP BY symbol"
  private def ms(ns: Long): Long   = ns / 1000000L
  private def list(xs: Seq[Long])  = xs.mkString("[", ",", "]")
  private def append(line: String) =
    Files.write(out, (line + "\n").getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND)

  private def localDir(location: String): File =
    if (location.startsWith("file:")) new File(new URI(location)) else new File(location)

  private def logVersions(dir: File): Seq[Long] =
    Option(new File(dir, "_delta_log").listFiles()).toSeq.flatten
      .map(_.getName)
      .filter(n => n.endsWith(".json") && n.length == 25)
      .map(_.take(20).toLong)
      .sorted

  private def commitInfo(dir: File, version: Long): (Long, String) = {
    val file  = new File(new File(dir, "_delta_log"), f"$version%020d.json")
    val lines = Files.readAllLines(file.toPath, StandardCharsets.UTF_8).asScala
    lines.map(l => mapper.readTree(l)).find(_.has("commitInfo")).map(_.get("commitInfo")) match {
      case Some(ci) => (ci.path("timestamp").asLong(), ci.path("operation").asText(""))
      case None     => (-1L, "none")
    }
  }

  private def telemetry: Vector[JsonNode] =
    Option(queue.listFiles()).toVector.flatten.filter(_.getName.endsWith(".jsonl")).sortBy(_.getName).flatMap { f =>
      Files.readAllLines(f.toPath, StandardCharsets.UTF_8).asScala.map(l => mapper.readTree(l))
    }

  private def phaseMs(events: Vector[JsonNode], id: String, pred: String => Boolean): Long =
    ms(
      events
        .filter(n => n.path("request_id").asText("") == id && n.path("event_type").asText("") == "phase")
        .filter(n => pred(n.path("phase").asText("")))
        .map(_.path("inclusive_ns").asLong())
        .sum
    )

  private def awaitTelemetry(ids: Seq[String]): Vector[JsonNode] = {
    val deadline = System.nanoTime() + 30000000000L
    var events   = telemetry
    def done = ids.forall(id =>
      events.exists(n => n.path("request_id").asText("") == id && n.path("operation").asText("") == "refresh")
    )
    while (!done && System.nanoTime() < deadline) { Thread.sleep(500L); events = telemetry }
    events
  }

  private def applyDelta(step: Int): Unit = {
    sql(
      s"INSERT INTO $src SELECT concat('sym_', cast(id % 20 as string)), cast(${1000 + step * 100} + id as int) " +
        "FROM range(40)"
    )
    sql(s"DELETE FROM $src WHERE symbol = 'sym_${step % 20}' AND amount % 2 = 0")
  }

  private def runBatch(label: String): B3Batch = {
    val ids      = (1 to MvCount).map(i => s"$prefix-$label-mv$i")
    val gate     = new java.util.concurrent.CountDownLatch(1)
    val submit   = new Array[Long](MvCount)
    val ack      = new Array[Long](MvCount)
    val ackEpoch = new Array[Long](MvCount)
    var start    = 0L
    TestPools.withPool(MvCount) { implicit ec =>
      val futures = (0 until MvCount).map { idx =>
        Future {
          spark.sparkContext.setLocalProperty("openivm.request_id", ids(idx))
          gate.await()
          submit(idx) = System.nanoTime()
          try spark.sql(s"REFRESH MATERIALIZED VIEW ${mv(idx + 1)}").collect()
          finally {
            ack(idx) = System.nanoTime(); ackEpoch(idx) = System.currentTimeMillis()
            spark.sparkContext.setLocalProperty("openivm.request_id", null)
          }
        }
      }
      start = System.nanoTime()
      gate.countDown()
      Await.result(Future.sequence(futures), 15.minutes)
    }
    B3Batch(ids, start, submit.toSeq, ack.toSeq, ackEpoch.toSeq)
  }

  private def fsDiff(a: Map[String, Long], b: Map[String, Long]): String =
    b.toSeq.sorted.collect { case (k, v) if v - a.getOrElse(k, 0L) != 0L => s"$k:${v - a.getOrElse(k, 0L)}" }.mkString(",")

  it(s"measures B3 marker and deferred-flush latency ($variant)") {
    Files.deleteIfExists(out)
    sql(s"CREATE TABLE $src(symbol STRING, amount INT) USING DELTA")
    sql(s"INSERT INTO $src SELECT concat('sym_', cast(id % 20 as string)), cast(id as int) FROM range(200)")
    (1 to MvCount).foreach(i => sql(s"CREATE MATERIALIZED VIEW ${mv(i)} AS ${expected(i)}"))
    val dirs = (1 to MvCount).map { i =>
      val id = spark.sessionState.sqlParser.parseTableIdentifier(mv(i))
      localDir(MvCatalog.lookup(spark, id).getOrElse(fail(s"${mv(i)} missing")).location)
    }
    val catalog = localDir(FeatureGate.catalogPath(spark).stripSuffix("/"))
    val srcDir  = localDir(spark.sql(s"DESCRIBE DETAIL $src").select("location").head().getString(0))
    append(
      s"variant=$variant spark=${org.apache.spark.SPARK_VERSION} build=$build warehouse=$warehouseDir " +
        s"note=local-disk+StateGuardFsInjection(object-store-modeled-v1); NOT OneLake"
    )

    applyDelta(0)
    runBatch("warmup")
    RefreshSqlLogAsyncFlusher.awaitQuiescence(120000L) shouldBe true
    B3Records.awaitIdle(System.nanoTime())

    val profile = StateGuardLatency.modeled(1.0)

    def measure(label: String, step: Int, waitFlush: Boolean, deltaUnderInjection: Boolean): Long = {
      if (deltaUnderInjection) applyDelta(step)
      else {
        StateGuardFsInjection.disable(); applyDelta(step); StateGuardFsInjection.configure(profile)
      }
      val before    = dirs.map(d => logVersions(d).last)
      val metaBefore = logVersions(new File(catalog, "mv_metadata")).size
      val cdfBefore  = logVersions(new File(catalog, "cdf_watermarks")).size
      val fs0       = StateGuardFsInjection.snapshot()
      val batch     = runBatch(label)
      val lastAck   = batch.ack.max
      val fs1       = StateGuardFsInjection.snapshot()
      val pendingAtAck = B3Records.pendingCount
      val drain0    = System.nanoTime()
      RefreshSqlLogAsyncFlusher.awaitQuiescence(120000L) shouldBe true
      val drainMs   = ms(System.nanoTime() - drain0)
      val flushNs   = if (waitFlush) B3Records.awaitIdle(lastAck) else -2L
      val fs2       = StateGuardFsInjection.snapshot()
      val metaAfter = logVersions(new File(catalog, "mv_metadata")).size
      val cdfAfter  = logVersions(new File(catalog, "cdf_watermarks")).size
      val events    = awaitTelemetry(batch.ids)
      val perView = dirs.zipWithIndex.map { case (d, i) =>
        val added   = logVersions(d).filter(_ > before(i))
        val infos   = added.map(v => commitInfo(d, v))
        val markers = infos.filter(_._2 == "Manual Update")
        val data    = infos.filterNot(_._2 == "Manual Update")
        val dataTs  = data.lastOption.map(_._1).getOrElse(-1L)
        val markTs  = markers.lastOption.map(_._1).getOrElse(-1L)
        (
          added.size,
          infos.map(_._2.replace(' ', '_')).mkString("+"),
          if (dataTs > 0) batch.ackEpoch(i) - dataTs else -1L,
          if (markTs > 0 && dataTs > 0) markTs - dataTs else -1L,
          phaseMs(events, batch.ids(i), _ == "finalize_catalog_advance"),
          phaseMs(events, batch.ids(i), _ == "finalize_mark_consumed"),
          phaseMs(events, batch.ids(i), _.startsWith("finalize_"))
        )
      }
      append(
        s"batch=$label flush_waited=$waitFlush makespan_ms=${ms(lastAck - batch.startNs)} " +
          s"submit_to_ack_ms=${list(batch.ack.zip(batch.submit).map { case (a, s) => ms(a - s) })} " +
          s"mv_commits=${perView.map(_._1).mkString("[", ",", "]")} mv_ops=${perView.map(_._2).mkString("[", ";", "]")} " +
          s"data_commit_to_ack_ms=${list(perView.map(_._3))} marker_minus_data_commit_ms=${list(perView.map(_._4))} " +
          s"tel_finalize_catalog_advance_ms=${list(perView.map(_._5))} tel_finalize_mark_consumed_ms=${list(perView.map(_._6))} " +
          s"tel_finalize_all_ms=${list(perView.map(_._7))} pending_at_ack=$pendingAtAck query_log_drain_ms=$drainMs " +
          s"post_ack_flush_ms=${if (flushNs >= 0) ms(flushNs).toString else flushNs.toString} " +
          s"mv_metadata_commits=${metaAfter - metaBefore} cdf_watermarks_commits=${cdfAfter - cdfBefore} " +
          s"fs_refresh={${fsDiff(fs0, fs1)}} fs_after_ack={${fsDiff(fs1, fs2)}}"
      )
      ms(lastAck - batch.startNs)
    }

    StateGuardFsInjection.reset()
    StateGuardFsInjection.configure(profile)
    try {
      val isolated = (1 to 3).map(k => measure(s"isolated$k", k, waitFlush = true, deltaUnderInjection = false))
      val b2b = (4 to 6).map(k => measure(s"b2b$k", k, waitFlush = k == 6, deltaUnderInjection = true))
      append(s"summary isolated_makespan_ms=${list(isolated)} back_to_back_makespan_ms=${list(b2b)}")
    } finally StateGuardFsInjection.disable()

    val stored = spark.read.format("delta").load(new File(catalog, "mv_metadata").toURI.toString)
      .select("name", "last_version").collect().map(r => r.getString(0).split('.').last -> r.getLong(1)).toMap
    val cdf = spark.read.format("delta").load(new File(catalog, "cdf_watermarks").toURI.toString)
      .collect().map(r => r.getAs[String]("view_name").split('.').last -> r.getAs[Long]("version")).toMap
    val srcLatest = logVersions(srcDir).last
    val lag = (1 to MvCount).map { i =>
      val latest = logVersions(dirs(i - 1)).last
      s"${mv(i)}:stored=${stored.getOrElse(mv(i), -1L)},latest=$latest,cdf=${cdf.getOrElse(mv(i), -1L)},src=$srcLatest"
    }
    append(s"final_catalog ${lag.mkString(" ")}")
    (1 to MvCount).foreach(i => assertMvCorrect(mv(i), expected(i)))
    append("parity=ok (bidirectional EXCEPT ALL, 6 MVs)")
  }
}

class B3LatencyUnmodeledProbeSpec extends B3LatencyProbeBase("b3lat-u", "b3latu", "unmodeled-warehouse")

class B3LatencyModeledProbeSpec
    extends B3LatencyProbeBase("b3lat-m/_openivm_catalog_wh", "b3latm", "modeled-warehouse")
